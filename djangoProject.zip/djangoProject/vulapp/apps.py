from django.apps import AppConfig


class VulappConfig(AppConfig):
    name = 'vulapp'
