import codecs
import csv
import datetime
import os
import time

from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db.models import Q
from django.shortcuts import render, redirect

from django.views.decorators.csrf import csrf_exempt, csrf_protect
from django.views.decorators.http import require_http_methods

from .models import vul_info
from .form import VulUploadForm

# Create your views here.
from django.http import HttpResponse, Http404, StreamingHttpResponse


def index(request):
    sum = vul_info.objects.all().count()
    high = vul_info.objects.filter(severity='2').count()
    med = vul_info.objects.filter(severity='1').count()
    low = vul_info.objects.filter(severity='0').count()
    wgzs = vul_info.objects.filter(track_stauts='0').count()
    gzzs = vul_info.objects.filter(track_stauts='1').count()
    ygzs = vul_info.objects.filter(track_stauts='2').count()
    tgips = vul_info.objects.filter(Q(protection_status_ips=1) & Q(protection_status_sac=1)).count()
    tg = vul_info.objects.filter(Q(protection_status_ips=0) & Q(protection_status_sac=1)).count()
    ips = vul_info.objects.filter(Q(protection_status_ips=1) & Q(protection_status_sac=0)).count()
    ntgips = vul_info.objects.filter(Q(protection_status_ips=0) & Q(protection_status_sac=0)).count()
    d = int(tgips / sum * 100)
    e = int(tg / sum * 100)
    f = int(ips / sum * 100)
    g = int(ntgips / sum * 100)
    a = int(wgzs / sum * 100)
    b = int(gzzs / sum * 100)
    c = int(ygzs / sum * 100)

    return render(request, 'index.html', {'sum': sum, 'high': high, 'med': med, 'low': low,
                                          'wgz': a, 'gzz': b, 'ygz': c,
                                          'wgzs': wgzs, 'gzzs': gzzs, 'ygzs': ygzs,
                                          'tgips': d, 'tg': e, 'ips': f,'ntgips': g,
                                          'tgipss': tgips, 'tgs': tg, 'ipss': ips,'ntgipss': ntgips})

@require_http_methods(["GET", ])
def vulinfo(request):
    data_sum = vul_info.objects.order_by('vul_id')
    paginator = Paginator(data_sum, 6)
    page = request.GET.get('page', 1)
    currentpage = int(page)
    all_page_num = paginator.num_pages
    try:
        # 获取当前页码的记录
        data_sum = paginator.page(page)
    except PageNotAnInteger:
        # 如果用户输入的页码不是整数时,显示第1页的内容
        data_sum = paginator.page(1)
    except EmptyPage:
        # 如果用户输入的页数不在系统的页码列表中时,显示最后一页的内容
        data_sum = paginator.page(paginator.num_pages)

    info = {
        "vuls": data_sum,
        "currentpage": currentpage,
        "all_page_num": all_page_num
    }

    return render(request, 'vulinfo.html', info)


@csrf_exempt
@require_http_methods(["GET", "POST"])
def vul_upload(request):
    if request.method == "POST":
        form = VulUploadForm(request.POST)
        print(request.POST)

        file_obj = request.FILES.get("poc_file", None)
        destination = open(os.path.join("/Users/kami/Desktop/python学习/djangoProject/poc", request.POST.get("poc_file")),'wb+')
        for i in file_obj.chunks():
            destination.write(i)
        destination.close()
        print(form)

        if form.is_valid():
            form.save()
            return HttpResponse("新增成功")
            content = {
                "form": form
            }
            return render(request, "insert.html", content)
        else:
            return HttpResponse('Sorry...')
    return render(request, 'insert.html')


@csrf_exempt
@require_http_methods(["GET", "POST"])
def vul_detail(request, vul_id):
    try:
        vul = vul_info.objects.get(vul_id=vul_id)
        content = {
            "vul": vul,
        }
    except Exception as e:
        raise Http404("Vul does not exist")

    return render(request, 'vuldetail.html', content)


def update_poc(request):
    if request.method == "POST":

        poc_info = request.POST.get('poc')
        vulid = request.POST.get('vul_id')
        vul_info.objects.filter(vul_id=vulid).update(poc=poc_info)
        return HttpResponse('save success!')

def update_poc_file(request):
    if request.method == "POST":
        poc_file = request.POST.get('poc_file')
        vulid = request.POST.get('vul_id')
        print(request.POST)
        file_obj = request.FILES.get("file", None)
        print(file_obj)
        destination = open(os.path.join("/Users/kami/Desktop/python学习/djangoProject/poc", poc_file),
                           'wb+')
        for i in file_obj.chunks():
            destination.write(i)
        destination.close()
        vul_info.objects.filter(vul_id=vulid).update(poc_file=poc_file)

        return HttpResponse('save success!')

def update_snort(request):
    if request.method == "POST":
        snort_info = request.POST.get('snort')
        snort_detail = request.POST.get('snort_detail')
        vulid = request.POST.get('vul_id')
        vul_info.objects.filter(vul_id=vulid).update(snort=snort_info)
        vul_info.objects.filter(vul_id=vulid).update(snort_detail=snort_detail)
        return HttpResponse('save success!')


def update_track(request):
    if request.method == "POST":
        track_info = request.POST.get('track_stauts', '')
        vulid = request.POST.get('vul_id')
        vul_info.objects.filter(vul_id=vulid).update(track_stauts=track_info)
        return HttpResponse('save success!')


def update_ips(request):
    if request.method == "POST":
        ips_info = request.POST.get('protection_status_ips', '')
        vulid = request.POST.get('vul_id')
        vul_info.objects.filter(vul_id=vulid).update(protection_status_ips=ips_info)
        return HttpResponse('save success!')


def update_sac(request):
    if request.method == "POST":
        sac_info = request.POST.get('protection_status_sac', '')
        vulid = request.POST.get('vul_id')
        vul_info.objects.filter(vul_id=vulid).update(protection_status_sac=sac_info)
        return HttpResponse('save success!')


def update_note(request):
    if request.method == "POST":
        note_info = request.POST.get('note', '')
        vulid = request.POST.get('vul_id')
        vul_info.objects.filter(vul_id=vulid).update(note=note_info)
        return HttpResponse('save success!')


def search(request):
    q = request.GET.get('q')
    search_list = vul_info.objects.filter(Q(name__icontains=q) | Q(cve__icontains=q) | Q(cnnvd__icontains=q) )
    error_msg = 'No result'
    return render(request, 'vulinfo.html', {'vuls': search_list,
                                            'error_msg': error_msg,
                                            })
def filter_1(request):
    search_lists = vul_info.objects.filter(Q(protection_status_ips=1) & Q(protection_status_sac=1))
    error_msg = 'No result'
    return render(request, 'vulinfo.html', {'vuls': search_lists,
                                            'error_msg': error_msg,
                                            })
def filter_2(request):
    search_lists = vul_info.objects.filter(Q(protection_status_ips=0) & Q(protection_status_sac=0))
    error_msg = 'No result'
    return render(request, 'vulinfo.html', {'vuls': search_lists,
                                            'error_msg': error_msg,
                                            })
def filter_3(request):
    search_lists = vul_info.objects.filter(Q(protection_status_ips=1) & Q(protection_status_sac=0))
    error_msg = 'No result'
    return render(request, 'vulinfo.html', {'vuls': search_lists,
                                            'error_msg': error_msg,
                                            })
def filter_4(request):
    search_lists = vul_info.objects.filter(Q(protection_status_ips=0) & Q(protection_status_sac=1))
    error_msg = 'No result'
    return render(request, 'vulinfo.html', {'vuls': search_lists,
                                            'error_msg': error_msg,
                                            })
def filter_5(request):
    search_lists = vul_info.objects.filter(Q(track_stauts=0))
    error_msg = 'No result'
    return render(request, 'vulinfo.html', {'vuls': search_lists,
                                            'error_msg': error_msg,
                                            })
def filter_6(request):
    search_lists = vul_info.objects.filter(Q(track_stauts=1))
    error_msg = 'No result'
    return render(request, 'vulinfo.html', {'vuls': search_lists,
                                            'error_msg': error_msg,
                                            })
def filter_7(request):
    search_lists = vul_info.objects.filter(Q(track_stauts=2))
    error_msg = 'No result'
    return render(request, 'vulinfo.html', {'vuls': search_lists,
                                            'error_msg': error_msg,
                                            })
def export(request):
    vul_lis = vul_info.objects.all()
    response = HttpResponse(content_type='text/csv')
    time_now = time.strftime('%Y%m%d')
    filename = 'vul_' + time_now
    response.write(codecs.BOM_UTF8)
    response['Content-Disposition'] = f'attachment; filename="{filename}.csv"'
    writer = csv.writer(response)
    writer.writerow(['vul_id', 'name', 'track', 'poc',
                     'snort', 'cve', 'cnnvd',
                     'ips', 'sac', 'note', 'update-time'])
    for vul in vul_lis:
        writer.writerow([vul.vul_id, vul.name, vul.track_stauts, vul.poc, vul.snort, vul.cve, vul.cnnvd,
                         vul.protection_status_ips, vul.protection_status_sac, vul.note, vul.updated_time])
    return response
def export_1(request):
    vul_lis = vul_info.objects.filter(Q(protection_status_ips=1) & Q(protection_status_sac=1))
    response = HttpResponse(content_type='text/csv')
    time_now = time.strftime('%Y%m%d')
    filename = 'vul_' + time_now
    response.write(codecs.BOM_UTF8)
    response['Content-Disposition'] = f'attachment; filename="{filename}.csv"'
    writer = csv.writer(response)
    writer.writerow(['vul_id', 'name', 'track', 'poc',
                     'snort', 'cve', 'cnnvd',
                     'ips', 'sac', 'note', 'update-time'])
    for vul in vul_lis:
        writer.writerow([vul.vul_id, vul.name, vul.track_stauts, vul.poc, vul.snort, vul.cve, vul.cnnvd,
                         vul.protection_status_ips, vul.protection_status_sac, vul.note, vul.updated_time])
    return response
def export_2(request):
    vul_lis = vul_info.objects.filter(Q(protection_status_ips=0) & Q(protection_status_sac=0))
    response = HttpResponse(content_type='text/csv')
    time_now = time.strftime('%Y%m%d')
    filename = 'vul_' + time_now
    response.write(codecs.BOM_UTF8)
    response['Content-Disposition'] = f'attachment; filename="{filename}.csv"'
    writer = csv.writer(response)
    writer.writerow(['vul_id', 'name', 'track', 'poc',
                     'snort', 'cve', 'cnnvd',
                     'ips', 'sac', 'note', 'update-time'])
    for vul in vul_lis:
        writer.writerow([vul.vul_id, vul.name, vul.track_stauts, vul.poc, vul.snort, vul.cve, vul.cnnvd,
                         vul.protection_status_ips, vul.protection_status_sac, vul.note, vul.updated_time])
    return response
def export_3(request):
    vul_lis = vul_info.objects.filter(Q(protection_status_ips=1) & Q(protection_status_sac=0))
    response = HttpResponse(content_type='text/csv')
    time_now = time.strftime('%Y%m%d')
    filename = 'vul_' + time_now
    response.write(codecs.BOM_UTF8)
    response['Content-Disposition'] = f'attachment; filename="{filename}.csv"'
    writer = csv.writer(response)
    writer.writerow(['vul_id', 'name', 'track', 'poc',
                     'snort', 'cve', 'cnnvd',
                     'ips', 'sac', 'note', 'update-time'])
    for vul in vul_lis:
        writer.writerow([vul.vul_id, vul.name, vul.track_stauts, vul.poc, vul.snort, vul.cve, vul.cnnvd,
                         vul.protection_status_ips, vul.protection_status_sac, vul.note, vul.updated_time])
    return response
def export_4(request):
    vul_lis = vul_info.objects.filter(Q(protection_status_ips=0) & Q(protection_status_sac=1))
    response = HttpResponse(content_type='text/csv')
    time_now = time.strftime('%Y%m%d')
    filename = 'vul_' + time_now
    response.write(codecs.BOM_UTF8)
    response['Content-Disposition'] = f'attachment; filename="{filename}.csv"'
    writer = csv.writer(response)
    writer.writerow(['vul_id', 'name', 'track', 'poc',
                     'snort', 'cve', 'cnnvd',
                     'ips', 'sac', 'note', 'update-time'])
    for vul in vul_lis:
        writer.writerow([vul.vul_id, vul.name, vul.track_stauts, vul.poc, vul.snort, vul.cve, vul.cnnvd,
                         vul.protection_status_ips, vul.protection_status_sac, vul.note, vul.updated_time])
    return response
def export_5(request):
    vul_lis = vul_info.objects.filter(Q(track_stauts=0))
    response = HttpResponse(content_type='text/csv')
    time_now = time.strftime('%Y%m%d')
    filename = 'vul_' + time_now
    response.write(codecs.BOM_UTF8)
    response['Content-Disposition'] = f'attachment; filename="{filename}.csv"'
    writer = csv.writer(response)
    writer.writerow(['vul_id', 'name', 'track', 'poc',
                     'snort', 'cve', 'cnnvd',
                     'ips', 'sac', 'note', 'update-time'])
    for vul in vul_lis:
        writer.writerow([vul.vul_id, vul.name, vul.track_stauts, vul.poc, vul.snort, vul.cve, vul.cnnvd,
                         vul.protection_status_ips, vul.protection_status_sac, vul.note, vul.updated_time])
    return response
def export_6(request):
    vul_lis = vul_info.objects.filter(Q(track_stauts=1))
    response = HttpResponse(content_type='text/csv')
    time_now = time.strftime('%Y%m%d')
    filename = 'vul_' + time_now
    response.write(codecs.BOM_UTF8)
    response['Content-Disposition'] = f'attachment; filename="{filename}.csv"'
    writer = csv.writer(response)
    writer.writerow(['vul_id', 'name', 'track', 'poc',
                     'snort', 'cve', 'cnnvd',
                     'ips', 'sac', 'note', 'update-time'])
    for vul in vul_lis:
        writer.writerow([vul.vul_id, vul.name, vul.track_stauts, vul.poc, vul.snort, vul.cve, vul.cnnvd,
                         vul.protection_status_ips, vul.protection_status_sac, vul.note, vul.updated_time])
    return response
def export_7(request):
    vul_lis = vul_info.objects.filter(Q(track_stauts=2))
    response = HttpResponse(content_type='text/csv')
    time_now = time.strftime('%Y%m%d')
    filename = 'vul_' + time_now
    response.write(codecs.BOM_UTF8)
    response['Content-Disposition'] = f'attachment; filename="{filename}.csv"'
    writer = csv.writer(response)
    writer.writerow(['vul_id', 'name', 'track', 'poc',
                     'snort', 'cve', 'cnnvd',
                     'ips', 'sac', 'note', 'update-time'])
    for vul in vul_lis:
        writer.writerow([vul.vul_id, vul.name, vul.track_stauts, vul.poc, vul.snort, vul.cve, vul.cnnvd,
                         vul.protection_status_ips, vul.protection_status_sac, vul.note, vul.updated_time])
    return response

def download_file(request, vul_id):

    search_lists = vul_info.objects.get(vul_id=vul_id)
    file_name = search_lists.poc_file
    the_file_name = '/Users/kami/Desktop/python学习/djangoProject/poc/'+ file_name
    file = open(the_file_name, 'rb')
    response = StreamingHttpResponse(file)
    response['Content-Type'] = 'application/octet-stream'
    response['Content-Disposition'] = 'attachement;filename="{0}"'.format(file_name)
    return response




