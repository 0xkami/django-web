"""djangoProject URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from vulapp import views

from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index, name='index'),
    path('index/', views.index, name='index'),
    path('vulinfo/', views.vulinfo, name='vulinfo'),
    path('insert/', views.vul_upload, name='insert'),
    path(r'^vulinfo/(?P<pageNumber>\d+)', views.vulinfo, name='vulinfo'),
    path("vuldetail/<int:vul_id>", views.vul_detail, name="vuldetail"),
    path('update_poc/', views.update_poc, name="update_poc"),
    path('update_poc_file/', views.update_poc_file, name="update_poc_file"),
    path('update_snort/', views.update_snort, name="update_snort"),
    path('update_track/', views.update_track, name="update_track"),
    path('update_ips/', views.update_ips, name="update_ips"),
    path('update_sac/', views.update_sac, name="update_sac"),
    path('update_note/', views.update_note, name="update_note"),
    path(r'^search/$', views.search, name='search'),
    path('filter_1/', views.filter_1, name='filter_1'),
    path('filter_2/', views.filter_2, name='filter_2'),
    path('filter_3/', views.filter_3, name='filter_3'),
    path('filter_4/', views.filter_4, name='filter_4'),
    path('filter_5/', views.filter_5, name='filter_5'),
    path('filter_6/', views.filter_6, name='filter_6'),
    path('filter_7/', views.filter_7, name='filter_7'),
    path('export/vulinfo/', views.export, name='export'),
    path('export/filter_1/', views.export_1, name='export'),
    path('export/filter_2/', views.export_2, name='export'),
    path('export/filter_3/', views.export_3, name='export'),
    path('export/filter_4/', views.export_4, name='export'),
    path('export/filter_5/', views.export_5, name='export'),
    path('export/filter_6/', views.export_6, name='export'),
    path('export/filter_7/', views.export_7, name='export'),
    path(r'^download/<int:vul_id>', views.download_file, name='download'),


] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)


