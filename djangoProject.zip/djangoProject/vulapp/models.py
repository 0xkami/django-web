import uuid
from datetime import datetime
from django.db import models

# Create your models here.
#负责数据库

class vul_info(models.Model):
   VUL_GRADE = (
       (0, u'低危'),
       (1, u'中危'),
       (2, u'高危'),
   )
   PROTECTION_STATUS_IPS = (
       (0, "IPS未防护"),
       (1, "IPS防护"),
   )
   PROTECTION_STATUS_SAC = (
       (0, "SAC未防护"),
       (1, "SAC防护")
   )
   TRACK_STAUTS = (
       (0, "未追踪"),
       (1, "追踪中"),
       (2, "追踪结束")
   )
   POC_STAUTS = (
       (0, "无"),
       (1, "有")
   )

   vul_id = models.AutoField(primary_key=True, verbose_name="漏洞ID")
   name = models.CharField(max_length=100, blank=False, default=" ", verbose_name="漏洞名称")
   severity = models.IntegerField(choices=VUL_GRADE, default=0, verbose_name="危险等级")
   protection_status_ips = models.IntegerField(choices=PROTECTION_STATUS_IPS, default=0, verbose_name="防护状态ips")
   protection_status_sac = models.IntegerField(choices=PROTECTION_STATUS_SAC, default=0, verbose_name="防护状态sac")
   cve = models.CharField(max_length=100, blank=True, default="", verbose_name="CVE编号")
   cnnvd = models.CharField(max_length=100, blank=True, default="", verbose_name="CNNVD编号")
   updated_time = models.DateField(verbose_name="漏洞更新时间")
   track_stauts = models.IntegerField(choices=TRACK_STAUTS, default=1, verbose_name="追踪状态")
   note = models.CharField(max_length=1000, blank=True, default="", verbose_name="备注")
   poc = models.IntegerField(choices=POC_STAUTS, default=0, verbose_name="POC状态")
   poc_file = models.CharField(max_length=1000, blank=True, default="", verbose_name="poc文件名")
   introduction = models.CharField(max_length=1000, blank=True, default="", verbose_name="详细介绍")
   affect_version = models.CharField(max_length=1000, blank=True, default="", verbose_name="影响版本")
   impact = models.CharField(max_length=1000, blank=True, default="", verbose_name="影响")
   solution_desc = models.CharField(max_length=1000, blank=True, default="", verbose_name="解决方案")
   person =  models.CharField(max_length=1000, blank=True, default="", verbose_name="负责人")
   snort = models.IntegerField(choices=POC_STAUTS, default=0, verbose_name="snort状态")
   snort_detail = models.CharField(max_length=1000, blank=True, default="", verbose_name="snort详情")
