from django import forms
from django.forms import TextInput, ModelForm, Textarea, Select

from vulapp.models import vul_info


class VulUploadForm(ModelForm):
    class Meta:
        model = vul_info
        fields = ['name', 'cve', 'cnnvd', 'severity', 'protection_status_ips',
                  'protection_status_sac', 'updated_time', 'track_stauts', 'note',
                  'introduction', 'affect_version', 'impact', 'solution_desc', 'poc', 'snort', 'person',
                  'snort_detail', 'poc_file']
        widgets = {
            'name': forms.TextInput(attrs={'class': 'custom-textinput'}),
            'cve': forms.TextInput(attrs={'class': 'custom-textinput'}),
            'cnnvd': forms.TextInput(attrs={'class': 'custom-textinput'}),
            'severity': forms.TextInput(attrs={'class': 'custom-textinput'}),
            'protection_status_ips': forms.TextInput(attrs={'class': 'custom-textinput'}),
            'protection_status_sac': forms.TextInput(attrs={'class': 'custom-textinput'}),
            'updated_time': forms.DateInput(attrs={'class': 'date-textinput'}),
            'track_stauts': forms.TextInput(attrs={'class': 'custom-textinput'}),
            'introduction': forms.TextInput(attrs={'class': 'custom-textinput'}),
            'note': forms.TextInput(attrs={'class': 'custom-textinput'}),
            'affect_version': forms.TextInput(attrs={'class': 'custom-textinput'}),
            'impact': forms.TextInput(attrs={'class': 'custom-textinput'}),
            'solution_desc': forms.TextInput(attrs={'class': 'custom-textinput'}),
            'poc': forms.TextInput(attrs={'class': 'custom-textinput'}),
            'poc_file': forms.TextInput(attrs={'class': 'custom-textinput'}),
            'snort': forms.TextInput(attrs={'class': 'custom-textinput'}),
            'snort_detail': forms.TextInput(attrs={'class': 'custom-textinput'}),
            'person': forms.TextInput(attrs={'class': 'custom-textinput'}),



        }

